# Transparent Keyboard Project

Custom Android keyboard with transparent design.